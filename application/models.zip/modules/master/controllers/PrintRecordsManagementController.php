<?php

class Master_PrintRecordsManagementController extends Zend_Controller_Action{
    public function init(){       
//        $bootstrap = $this->getInvokeArg("bootstrap");
//        $this->aConfig = $bootstrap->getOptions();
//        $this->view->aConfig = $this->aConfig;
//        $this->modelMapper= new Model_PrintMapperBase();
//        $this->model= new Model_Doc_Violations_Handling(); 
    }
    public function indexAction(){      
    }
     public function testbaocaoAction(){      
    }
    public function listdocviolationshandlingAction(){   
//      $redirectUrl=$this->aConfig["site"]["url"]."master/docviolationshandling/list/type_business/DoanhNghiep";
//        $this->_redirect($redirectUrl);
    }

//   public function serviceAction(){
//    $this->_helper->layout->disableLayout();
//        $type_business= $this->_getParam("type_business","");
//        foreach ($this->model->fetchAll() as $items ) {
//            $menber[]=array(
//                'id' => $items->getId(),
//                'date_violation'=> $items->getDate_Violation(),
//                'sys_user_id'=> $items->getSys_User_Id()
//                
//            );
//        }
//       
//        echo json_encode($menber);
//        exit();
//   }
}
