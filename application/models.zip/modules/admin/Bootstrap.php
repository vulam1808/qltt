<?php

class Admin_Bootstrap extends Zend_Application_Module_Bootstrap {

    /*	
void _initAutoloader ()
void _initCache ()
void _initConfig ()
void _initFrontPlugins ()
void _initLogger ()
void _initModulesResources ()
void _initRouter ()
void _initViewProperties ()
*/

}