<?php

class Zend_View_Helper_ImageUrl {

    function imageUrl() {
        return GlobalLib::getImageURL();
    }

}
