<?php
include APPLICATION_PATH."/models/base/Type_CriteriaBase.php";
/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
class Model_Type_Criteria extends Model_Type_CriteriaBase{
    
}
class Model_Type_CriteriaMapper extends Model_Type_CriteriaMapperBase{
//     public function findidbycode($district_code){
//        $db = Zend_Db_Table::getDefaultAdapter();
//        $select= "select id from district where district_code='$district_code'";
//        $stmt=$db->query($select);
//        $row = $stmt->fetchAll(PDO::FETCH_CLASS);
//        $stmt->closeCursor();
//        if($row==NULL){
//            return null;
//        }
//        return $row[0]->id;   
//    }
//    public function findidbyname($district_name){
//        $db = Zend_Db_Table::getDefaultAdapter();
//        $select= "select id from district where name='$district_name'";
//        $stmt=$db->query($select);
//        $row = $stmt->fetchAll(PDO::FETCH_CLASS);
//        $stmt->closeCursor();
//        if($row==NULL){
//            return null;
//        }
//        return $row[0]->id;   
//    }
}
